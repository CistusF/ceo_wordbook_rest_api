export type envTypes = {
    MONGO_DB_URI: string;
    npm_package_version: string;
}